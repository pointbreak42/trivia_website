"use client"

import { Button } from "@/components/ui/button"
import { SettingsMenu } from "@/components/settings-menu"
import { useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Define categories
const categories = [
  { id: "history", name: "History" },
  { id: "science", name: "Science" },
  { id: "geography", name: "Geography" },
  { id: "entertainment", name: "Entertainment" },
  { id: "sports", name: "Sports" },
]

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>("")

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-4 text-gray-800 dark:text-white transition-colors duration-300">
      {/* Noise filter */}
      <svg className="fixed left-0 top-0 h-full w-full opacity-0">
        <filter id="noise">
          <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
          <feBlend mode="multiply" in="SourceGraphic" />
        </filter>
      </svg>

      {/* Background with gradient and noise */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-b from-blue-100 to-purple-200 dark:from-gray-800 dark:to-gray-900" />
      <div className="fixed inset-0 -z-10 opacity-20 [filter:url(#noise)]" />

      {/* Hamburger icon for settings */}
      <div className="absolute left-4 top-4 z-10">
        <SettingsMenu />
      </div>

      <div className="container flex max-w-4xl flex-col items-center justify-center gap-8 text-center">
        <h1 className="text-6xl font-extrabold tracking-tight sm:text-8xl">
          <span className="block bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent drop-shadow-md">
            Brain
          </span>
          <span className="block bg-gradient-to-r from-orange-400 to-red-600 bg-clip-text text-transparent drop-shadow-md">
            Blast!
          </span>
        </h1>

        <div className="flex w-full max-w-xs flex-col items-center gap-4">
          <Button
            size="lg"
            className="w-full bg-gradient-to-r from-red-500 to-orange-500 px-8 py-6 text-xl font-bold text-white hover:from-red-600 hover:to-orange-600 dark:from-red-500 dark:to-orange-500 dark:hover:from-red-600 dark:hover:to-orange-600"
          >
            PLAY
          </Button>

          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="h-12 w-full bg-white/80 text-center text-lg font-medium text-gray-800 backdrop-blur-sm dark:bg-gray-800/80 dark:text-white">
              <SelectValue placeholder="Select Category" />
            </SelectTrigger>
            <SelectContent className="max-h-60">
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id} className="text-base">
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </main>
  )
}
